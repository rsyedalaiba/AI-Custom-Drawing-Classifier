import pickle
import os
import tkinter.messagebox
from tkinter import *
from tkinter import simpledialog, filedialog
import PIL
import PIL.Image, PIL.ImageDraw
import cv2 as cv
import numpy as np
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt

class DrawingClassifier:

    def __init__(self):
        self.class1, self.class2, self.class3 = None, None, None
        self.class1_counter, self.class2_counter, self.class3_counter = 1, 1, 1
        self.clf = LinearSVC()
        self.proj_name = None
        self.root = None
        self.image1 = None

        self.status_label = None
        self.canvas = None
        self.draw = None

        self.brush_width = 15

        self.classes_prompt()
        self.init_gui()

    def classes_prompt(self):
        msg = Tk()
        msg.withdraw()

        self.proj_name = simpledialog.askstring("Project Name", "Please enter your project name down below!", parent=msg)
        
        if os.path.exists(self.proj_name):
            try:
                with open(f"{self.proj_name}/{self.proj_name}_data.pickle", "rb") as f:
                    data = pickle.load(f)
                self.class1 = data['c1']
                self.class2 = data['c2']
                self.class3 = data['c3']
                self.class1_counter = data['c1c']
                self.class2_counter = data['c2c']
                self.class3_counter = data['c3c']
                self.clf = data['clf']
                self.proj_name = data['pname']
            except FileNotFoundError:
                self.create_new_project()
        else:
            self.create_new_project()

    def create_new_project(self):
        self.class1 = simpledialog.askstring("Class 1", "What is the first class called?")
        self.class2 = simpledialog.askstring("Class 2", "What is the second class called?")
        self.class3 = simpledialog.askstring("Class 3", "What is the third class called?")

        self.class1_counter = 1
        self.class2_counter = 1
        self.class3_counter = 1

        self.clf = LinearSVC()

        if not os.path.exists(self.proj_name):
            os.mkdir(self.proj_name)
            os.mkdir(f"{self.proj_name}/{self.class1}")
            os.mkdir(f"{self.proj_name}/{self.class2}")
            os.mkdir(f"{self.proj_name}/{self.class3}")

        data = {"c1": self.class1, "c2": self.class2, "c3": self.class3, "c1c": self.class1_counter,
                "c2c": self.class2_counter, "c3c": self.class3_counter, "clf": self.clf, "pname": self.proj_name}

        with open(f"{self.proj_name}/{self.proj_name}_data.pickle", "wb") as f:
            pickle.dump(data, f)

    def init_gui(self):
        WIDTH = 500
        HEIGHT = 500
        WHITE = (255, 255, 255)

        self.root = Tk()
        self.root.title(f"NeuralNine Drawing Classifier Alpha v0.2 - {self.proj_name}")

        self.canvas = Canvas(self.root, width=WIDTH-10, height=HEIGHT-10, bg="white")
        self.canvas.pack(expand=YES, fill=BOTH)
        self.canvas.bind("<B1-Motion>", self.paint)

        self.image1 = PIL.Image.new("RGB", (WIDTH, HEIGHT), WHITE)
        self.draw = PIL.ImageDraw.Draw(self.image1)

        btn_frame = Frame(self.root)
        btn_frame.pack(fill=X, side=BOTTOM)

        btn_frame.columnconfigure(0, weight=1)
        btn_frame.columnconfigure(1, weight=1)
        btn_frame.columnconfigure(2, weight=1)

        class1_btn = Button(btn_frame, text=self.class1, command=lambda: self.save (1))
        class1_btn.grid(row=0, column=0, sticky=W + E)

        class2_btn = Button(btn_frame, text=self.class2, command=lambda: self.save(2))
        class2_btn.grid(row=0, column=1, sticky=W + E)

        class3_btn = Button(btn_frame, text=self.class3, command=lambda: self.save(3))
        class3_btn.grid(row=0, column=2, sticky=W + E)

        bm_btn = Button(btn_frame, text="Brush-", command=self.brushminus)
        bm_btn.grid(row=1, column=0, sticky=W + E)

        clear_btn = Button(btn_frame, text="Clear", command=self.clear)
        clear_btn.grid(row=1, column=1, sticky=W + E)

        bp_btn = Button(btn_frame, text="Brush+", command=self.brushplus)
        bp_btn.grid(row=1, column=2, sticky=W + E)

        train_btn = Button(btn_frame, text="Train Model", command=self.train_model)
        train_btn.grid(row=2, column=0, sticky=W + E)

        save_btn = Button(btn_frame, text="Save Model", command=self.save_model)
        save_btn.grid(row=2, column=1, sticky=W + E)

        load_btn = Button(btn_frame, text="Load Model", command=self.load_model)
        load_btn.grid(row=2, column=2, sticky=W + E)

        change_btn = Button(btn_frame, text="Change Model", command=self.rotate_model)
        change_btn.grid(row=3, column=0, sticky=W + E)

        predict_btn = Button(btn_frame, text="Predict", command=self.predict)
        predict_btn.grid(row=3, column=1, sticky=W + E)

        save_everything_btn = Button(btn_frame, text="Save Everything", command=self.save_everything)
        save_everything_btn.grid(row=3, column=2, sticky=W + E)

        plot_accuracy_btn = Button(btn_frame, text="Plot Accuracy", command=self.plot_accuracy)
        plot_accuracy_btn.grid(row=4, column=0, sticky=W + E)

        exit_btn = Button(btn_frame, text="Exit", command=self.on_closing)
        exit_btn.grid(row=4, column=1, sticky=W + E)

        self.status_label = Label(btn_frame, text=f"Current Model: {type(self.clf).__name__}")
        self.status_label.config(font=("Arial", 10))
        self.status_label.grid(row=4, column=2, sticky=W + E)

        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.root.attributes("-topmost", True)
        self.root.mainloop()

    def paint(self, event):
        x1, y1 = (event.x - 1), (event.y - 1)
        x2, y2 = (event.x + 1), (event.y + 1)
        self.canvas.create_rectangle(x1, y1, x2, y2, fill="black", width=self.brush_width)
        self.draw.rectangle([x1, y1, x2 + self.brush_width, y2 + self.brush_width], fill="black", width=self.brush_width)

    def save(self, class_num):
        self.image1.save("temp.png")
        img = PIL.Image.open("temp.png")
        img.thumbnail((50, 50), PIL.Image.Resampling.LANCZOS)

        if class_num == 1:
            img.save(f"{self.proj_name}/{self.class1}/{self.class1_counter}.png", "PNG")
            self.class1_counter += 1
        elif class_num == 2:
            img.save(f"{self.proj_name}/{self.class2}/{self.class2_counter}.png", "PNG")
            self.class2_counter += 1
        elif class_num == 3:
            img.save(f"{self.proj_name}/{self.class3}/{self.class3_counter}.png", "PNG")
            self.class3_counter += 1

        self.clear()

    def brushminus(self):
        if self.brush_width > 1:
            self.brush_width -= 1

    def brushplus(self):
        self.brush_width += 1

    def clear(self):
        self.canvas.delete("all")
        self.draw.rectangle([0, 0, 1000, 1000], fill="white")

    def train_model(self):
        img_list = []
        class_list = []

        for x in range(1, self.class1_counter):
            img = cv.imread(f"{self.proj_name}/{self.class1}/{x}.png")[:, :, 0]
            img = img.reshape(2500)
            img_list.append(img)
            class_list.append(1)
  
        for x in range(1, self.class2_counter):
            img = cv.imread(f"{self.proj_name}/{self.class2}/{x}.png")[:, :, 0]
            img = img.reshape(2500)
            img_list.append(img)
            class_list.append(2)

        for x in range(1, self.class3_counter):
            img = cv.imread(f"{self.proj_name}/{self.class3}/{x}.png")[:, :, 0]
            img = img.reshape(2500)
            img_list.append(img)
            class_list.append(3)

        img_list = np.array(img_list)
        class_list = np.array(class_list)

        X_train, X_test, y_train, y_test = train_test_split(img_list, class_list, test_size=0.2, random_state=42)

        self.clf.fit(X_train, y_train)

        y_pred = self.clf.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)

        tkinter.messagebox.showinfo("NeuralNine Drawing Classifier", 
                                      f"Model successfully trained! Accuracy: {accuracy * 100:.2f}%", parent=self.root)

        self.status_label.config(text=f"Current Model: {type(self.clf).__name__} - Accuracy: {accuracy * 100:.2f}%")

    def plot_accuracy(self):
        models = {
            "Linear SVC": LinearSVC(),
            "K-Nearest Neighbors": KNeighborsClassifier(),
            "Naive Bayes": GaussianNB(),
            "Logistic Regression": LogisticRegression(),
            "Decision Tree": DecisionTreeClassifier(),
            "Random Forest": RandomForestClassifier(),
        }
        
        img_list = []
        class_list = []

        for x in range(1, self.class1_counter):
            img = cv.imread(f"{self.proj_name}/{self.class1}/{x}.png")[:, :, 0]
            img = img.reshape(2500)
            img_list.append(img)
            class_list.append(1)

        for x in range(1, self.class2_counter):
            img = cv.imread(f"{self.proj_name}/{self.class2}/{x}.png")[:, :, 0]
            img = img.reshape(2500)
            img_list.append(img)
            class_list.append(2)

        for x in range(1, self.class3_counter):
            img = cv.imread(f"{self.proj_name}/{self.class3}/{x}.png")[:, :, 0]
            img = img.reshape(2500)
            img_list.append(img)
            class_list.append(3)

        img_list = np.array(img_list)
        class_list = np.array(class_list)

        X_train, X_test, y_train, y_test = train_test_split(img_list, class_list, test_size=0.2, random_state=42)
        accuracies = {}

        for model_name, model in models.items():
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            accuracies[model_name] = accuracy

        model_names = list(accuracies.keys())
        accuracy_values = list(accuracies.values())

        plt.figure(figsize=(10, 6))
        plt.bar(model_names, accuracy_values, color=['blue', 'green', 'orange', 'red', 'purple'])
        plt.xlabel('Model')
        plt.ylabel('Accuracy')
        plt.title('Model Comparison')
        plt.ylim(0, 1)  # Accuracy ranges from 0 to 1
        plt.show()

    def predict(self):
        self.image1.save("temp.png")
        img = PIL.Image.open("temp.png")
        img.thumbnail((50, 50), PIL.Image.Resampling.LANCZOS)
        img.save("predictshape.png", "PNG")

        img = cv.imread("predictshape.png")[:, :, 0]
        img = img.reshape(2500)
        prediction = self.clf.predict([img])

        if hasattr(self.clf, "predict_proba"):
            prob = self.clf.predict_proba([img])
            confidence = np.max(prob) * 100
            print(f"Model Name: {type(self.clf).__name__}, Prediction: {prediction[0]}, Confidence: {confidence:.2f}%")

        if prediction[0] == 1:
            tkinter.messagebox.showinfo("NeuralNine Drawing Classifier", f"The drawing is probably a {self.class1}", parent=self.root)
        elif prediction[0] == 2:
            tkinter.messagebox.showinfo("NeuralNine Drawing Classifier", f"The drawing is probably a {self.class2}", parent=self.root)
        elif prediction[0] == 3:
            tkinter.messagebox.showinfo("Ne uralNine Drawing Classifier", f"The drawing is probably a {self.class3}", parent=self.root)

    def rotate_model(self):
        if isinstance(self.clf, LinearSVC):
            self.clf = KNeighborsClassifier()
        elif isinstance(self.clf, KNeighborsClassifier):
            self.clf = GaussianNB()
        elif isinstance(self.clf, GaussianNB):
            self.clf = LogisticRegression()
        elif isinstance(self.clf, LogisticRegression):
            self.clf = DecisionTreeClassifier()
        elif isinstance(self.clf, DecisionTreeClassifier):
            self.clf = RandomForestClassifier()
        else:
            self.clf = LinearSVC()

        self.status_label.config(text=f"Current Model: {type(self.clf).__name__}")

    def save_model(self):
        with open(f"{self.proj_name}/{self.proj_name}_model.pickle", "wb") as f:
            pickle.dump(self.clf, f)

    def load_model(self):
        model_path = filedialog.askopenfilename(filetypes=[("Pickle Files", "*.pickle")])
        with open(model_path, "rb") as f:
            self.clf = pickle.load(f)
        self.status_label.config(text=f"Current Model: {type(self.clf).__name__}")

    def save_everything(self):
        data = {"c1": self.class1, "c2": self.class2, "c3": self.class3, "c1c": self.class1_counter,
                "c2c": self.class2_counter, "c3c": self.class3_counter, "clf": self.clf, "pname": self.proj_name}

        with open(f"{self.proj_name}/{self.proj_name}_data.pickle", "wb") as f:
            pickle.dump(data, f)

    def on_closing(self):
        self.root.quit()
        self.root.destroy()

if __name__ == "__main__":
    DrawingClassifier()